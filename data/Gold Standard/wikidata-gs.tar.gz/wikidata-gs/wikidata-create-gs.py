import sys

with open(sys.argv[1], 'r') as f:
     state = 0
     f2 = None
     for l in f:
          if state == 0 and len(l) > 1 and l[0] == "P":
               ll = l.split(" ")
               variable = "y" if "-1" in ll[0] else "x"
               relation = ll[0].replace("-1", "")
               f2 = open("_".join(["gs", relation, variable]), "w")
               state = 1
               continue
          if state == 1:
               if l.strip():
                    f2.write("<" + l.split(" ")[0] + ">\n")
               else:
                    f2.close()
                    state = 0
     try:
          f2.close()
     except:
          pass
